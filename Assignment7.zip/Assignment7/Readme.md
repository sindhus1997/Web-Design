
 navbar has Home and About. 

 SASS components used

- Variables - Variables can be seen in the style.css file where root color is declared.
- Nesting - In scss file, nesting is not for every section of the page.
- Interpolation - @extend property in buttons file where it extends the main btn properties.
- Placeholder Selectors - Placeholder selectors are useful when writing a Sass library where each style rule may or may not be used
- Functions - There is a function which changes the color of the background basd on the percentage of intensity of the color.
- Custom Properties - Custom background color called as --first-color
- Mixins -Mixins is used for grid style and title text for the homepage

