# Assignment 1




This website allows user to find free things to do in NYC
 
The HTML <img> tag is used to embed an image in a web page. I have added different images to make the UI more attractive.
 
A favicon image is displayed to the left of the page title in the browser tab. I have added favicon for NYC website which is a travel icon.
  
Document titles are defined by the 'title' element.
 
The visible part of the HTML document is between the 'body' and the '/body' tags.

For part B, I have used HTML 5 tags mentioned below:

<header> -	Represents the header of a document or a section. header here is 'Tourist's favourites'
<audio> - Embeds a sound, or an audio stream in an HTML document. I have also added audio below the form using <audio> tag.
<footer> -	Represents the footer of a document or a section. In this case footer is 'COPYRIGHT 2023'
<main> -	Represents the main or dominant content of the document. In this website main area is the middle part of the webite where forms and audio are residing.
<article> -	Defines an article. I have defined the header part as an article in this case.





NAME: Sindhu

NUID: 002920301