# Assignment 1


The project is for the first assignment of the web design course and demonstrates HTML and CSS. Following are tags I've used while creating the website.

This website 
 
Headings in HTML are defined using the h1 to h6 tags.
 
The h1 tag defines the most important heading. h6> determines the least important heading.
  
Styles can be applied to an element using the HTML style attribute, such as color, font, and size.
 
The HTML <b> element defines bold text, without offering any added value.
 
The HTML <img> tag is used to embed an image in a web page. Image i have used in the webiste is the logo.
 
A favicon image is displayed to the left of the page title in the browser tab.
 
Tables are used to organize data onto rows or columns in web pages. Each table cell is defined by a <td> and an </td> tag. The content of the table cell is between the <td> and </td> tags. Each table row begins with a <tr> tag and ends with a </tr> tag. The table in the website is created in the second page about where the table defined the timings.
 
Unordered (bulleted) lists are defined by the HTML 'ul' tag.
 
Document titles are defined by the 'title' element. 
 
The visible part of the HTML document is between the 'body' and the '/body' tags.




NAME: Sindhu

NUID: 002920301